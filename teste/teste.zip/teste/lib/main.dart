import 'package:flutter/material.dart';
import 'package:teste/questao.dart';
import 'package:teste/resposta.dart';
import 'package:teste/congrats.dart';

///dart so funciona para android
///flutter serve tanto para IOS quanto para ANDROID (mult-platafform)

main(){
  runApp(new QuizApp());

}
/// a funcao busca por indice e exibe as perguntas a partir do indice 0 ///

class PerguntaAppState extends State <QuizApp>{

  var perguntaResp=0; ///pergunta que foi selecionada
  var pontosTotal = 0; /// conta os pontos
  final perguntas=[
    {
      'texto':'Qual é seu nome?',
      'resposta': [
        {'texto':'Cae', 'pontos': 10} ,       ///antes so tinha string agr virou uma list de objetos  devido a: {}
        {'texto':'Tano', 'pontos': 1} ,
        {'texto':'Augusto', 'pontos': 2}
      ]
    },

    {
      'texto':'pq esse teclado eh podre',
      'resposta': [
        {'texto':'arquimedes', 'pontos': 10} ,
        {'texto':'duro', 'pontos': 12} ,
        {'texto':'podre', 'pontos': 21}
      ]
    },

    {
      'texto':'quem eh?',
      'resposta': [
        {'texto':'renato', 'pontos': 10} ,
        {'texto':'gaucho', 'pontos': 30} ,
        {'texto':'dorival', 'pontos': 20}   ///''texto'' e ''pontos'' nao podem mudar pq serao comuns a todas as questions
      ]
    },

  ];

  void responder(int pontos){  ///quando chamar a funcao acontece isso:
    if(temperguntaResp){
      setState(() {
        perguntaResp++;
        pontosTotal += pontos;
    });
  }
}

  bool get temperguntaResp{
    return perguntaResp < perguntas.length;
}



  Widget build(BuildContext context){

    List<Map<String, Object>> respostas= temperguntaResp
     ? perguntas[perguntaResp].cast()['resposta'] ///se for verdade
     : [];   ///se for falso

    ///ao inves de usar aquele FOR vamos usar essa funcao MAP

                      //List<Widget> respostas=[];
                      //for (String txtResp in perguntas[perguntaResp].cast()['resposta']){
                      // respostas.add(Resposta(txtResp, responder));
                      //}


    return MaterialApp( /// é aqui que retorna os componentes visuais da tela
      home: Scaffold(
        appBar: AppBar(
          title: Text('Quizz'),
        ),
        body: temperguntaResp ///se a função for verdadeira ele exibe a Column
        ? Column(
          children: [
            Text('opa'),
            Questao(perguntas[perguntaResp]['texto'].toString()),
            ...respostas
                .map((resp) => Resposta(resp['texto'].toString(), () => responder(int.parse(resp['pontos'].toString()))))
                .toList() ///toList serve para converter um monte de string para lista
          ],
        ) ///caso contrario=
        : Congrats(pontosTotal)
      ),
    );
  }
}


class QuizApp extends StatefulWidget{
 PerguntaAppState createState(){
   return PerguntaAppState();
 }
}


