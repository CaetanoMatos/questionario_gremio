import 'package:flutter/material.dart';
class Congrats extends StatelessWidget {
  final int pontos;
  Congrats(this.pontos);

     Widget build(BuildContext context){
       return Container(
         child: Column(
           children: [
             Text('parabens  deu certo, sua pontuacao é de $pontos',
             style: TextStyle(fontSize: 40)),
           ],
         ),
       );
     }


  }